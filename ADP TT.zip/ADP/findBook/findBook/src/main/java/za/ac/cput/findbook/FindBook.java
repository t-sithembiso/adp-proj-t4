/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
//VIEWS
package za.ac.cput.findbook;

import Client.ClientClass;
import Domain.FindBookPOJO;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;

/**
 *
 * @author Thlitha Sithembiso
 */

public class FindBook extends JFrame implements ActionListener {

    JButton BtnSave, BtnClose, BtnReset;
    JLabel pnlLabel, lblISBN, lblBookTitle, lblCatergory, lblName, lblShelfNumber;
    JTextField txtISBN, txtBookTitle, txtCatergory, txtName, txtShelfNumber;
    JPanel panelN, panelC, panelS;

    FindBookPOJO POJO = new FindBookPOJO();
    ClientClass Client = new ClientClass();

    public void GUI() {
        //PANELS AND JFRAME
        setTitle("BOOKS");
        setSize(500, 600);
        setResizable(false);

        //Labels
        lblISBN = new JLabel("ISBN");
        lblBookTitle = new JLabel("Book Title");
        lblCatergory = new JLabel("Catergory");
        lblName = new JLabel("Name");
        lblShelfNumber = new JLabel("Shelf Number");
        //Labels

        //TEXTFIELDS
        txtISBN = new JTextField();
        txtBookTitle = new JTextField();
        txtCatergory = new JTextField();
        txtName = new JTextField();
        txtShelfNumber = new JTextField();
        //TEXTFIELDS

        //Buttons
        BtnSave = new JButton("SAVE");
        BtnSave.addActionListener(this);

        BtnClose = new JButton("CLOSE");
        BtnClose.addActionListener(this);

        BtnReset = new JButton("RESET");
        BtnReset.addActionListener(this);
        //Buttons

        //PANELS
        panelN = new JPanel();
        panelN.setBackground(Color.blue);
        pnlLabel = new JLabel("BOOK MANAGEMENT SYSTEM");
        pnlLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        pnlLabel.setBounds(0, 10, 140, 140);
        panelN.add(pnlLabel);
        add(panelN, BorderLayout.NORTH);
        //NORTH

        //CENTER
        panelC = new JPanel();
        panelC.setLayout(new GridLayout(5, 2));
        panelC.setBackground(Color.gray);
        panelC.add(lblISBN);
        panelC.add(txtISBN);

        panelC.add(lblBookTitle);
        panelC.add(txtBookTitle);

        panelC.add(lblCatergory);
        panelC.add(txtCatergory);

        panelC.add(lblName);
        panelC.add(txtName);

        panelC.add(lblShelfNumber);
        panelC.add(txtShelfNumber);
        add(panelC, BorderLayout.CENTER);

        //SOUTH
        panelS = new JPanel();
        panelS.setLayout(new GridLayout(1, 3));
        panelS.setBackground(Color.gray);
        panelS.add(BtnSave);
        panelS.add(BtnClose);
        panelS.add(BtnReset);
        add(panelS, BorderLayout.SOUTH);

        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }

        });

    }

    public void runclient() {

        try {
            Client.connection();
            Client.streams();
        } catch (IOException IO) {
            JOptionPane.showMessageDialog(null, IO.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == BtnClose) {
            System.exit(0);
        }
        if (e.getSource() == BtnReset) {
            txtISBN.setText("");
            txtBookTitle.setText("");
            txtCatergory.setText("");
            txtName.setText("");
            txtShelfNumber.setText("");
        }

        if (e.getSource() == BtnSave) {
            
            //getting data from textfeild to send to pojo then send to clent then to server pojo then to dao

            String ISBN = txtISBN.getText();
            String BookTitle = txtBookTitle.getText();
            String Catergory = txtCatergory.getText();
            String Name = txtName.getText();
            String ShelfNumber = txtShelfNumber.getText();

             FindBookPOJO  B = new FindBookPOJO(ISBN, BookTitle, Catergory, Name, ShelfNumber);
              try{
             
           Client.sendData(B);
           
           }catch(IOException oe){
               System.out.println("Exception");
           }
        }
    }

    public static void main(String[] args) {
        FindBook FB = new FindBook();
        FB.GUI();
        
    }
}
