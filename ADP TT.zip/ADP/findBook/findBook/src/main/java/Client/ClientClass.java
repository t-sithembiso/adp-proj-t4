/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Client;

import Domain.FindBookPOJO;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author Thalitha Sithembiso
 */
public class ClientClass {

    private Socket Sock;
    private ObjectOutputStream outptStream;
    // private ObjectInputStream inStream;
  
    public void connection() {

        try {
            Sock = new Socket("localhost", 1234);
            System.out.println("Connected");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        // go.GUI();
    }

    public void sendData(FindBookPOJO B) throws IOException {
        
        System.out.println(B+"Client");
        outptStream.writeObject("book");
        outptStream.writeObject(B);
        outptStream.flush();
    }

    public void streams() throws IOException {
        outptStream = new ObjectOutputStream(Sock.getOutputStream());
        outptStream.flush();
        // inStream = new ObjectInputStream(soc.getInputStream());
    }

     public void close() throws IOException {
        Sock.close();
        outptStream.close();
     //   inStream.close();
    } 
}

