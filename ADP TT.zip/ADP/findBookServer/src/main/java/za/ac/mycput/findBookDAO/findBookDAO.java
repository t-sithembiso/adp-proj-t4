/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.mycput.findBookDAO;

import za.ac.mycput.domain.findBook;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Thalitha Sithembiso
 */
public class findBookDAO {

    Connection connection = null;

    public findBookDAO() {
    }

    public void select() throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/booksDB ", "username", "password");

        String sql = "SELECT * FROM BOOKS_TBL";

        PreparedStatement prepStatement = connection.prepareStatement(sql);

        ResultSet resultSet = prepStatement.executeQuery();

    }

    public void insert(findBook fb) throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/booksDB ", "username", "password");

        String sql = "INSERT INTO BOOKS_TBL (ISBN, )  VALUES (?,?,?,?,?,?)";

        PreparedStatement prepStatement = connection.prepareStatement(sql);
        
        prepStatement.setString(1, fb.getISBN());
        prepStatement.setString(2, fb.getBookTitle());
           prepStatement.setString(3, fb.getCatergory());
            prepStatement.setString(4, fb.getName());
            prepStatement.setString(5, fb.getShelfNumber());

        int valid = prepStatement.executeUpdate();

        if (valid > 0) {
            JOptionPane.showMessageDialog(null, "Inserted!");
        } else {
            JOptionPane.showMessageDialog(null, "Error! Couldn't enter book");
        }

    }

    public void update(findBook fb) throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/booksDB ", "username", "password");

        String sql = "UPDATE FROM BOOKS_TBL SET BookTitle = ?, Catergory =?,  ISBN =?,Name =?, ShelfNumber =? WHERE ISBN = ?";

        PreparedStatement prepStatement = connection.prepareStatement(sql);

        prepStatement.setString(2, fb.getBookTitle());
           prepStatement.setString(3, fb.getCatergory());
            prepStatement.setString(4, fb.getName());
            prepStatement.setString(5, fb.getShelfNumber());

        int valid =  prepStatement.executeUpdate();

        if (valid > 0) {
            JOptionPane.showMessageDialog(null, "Updated!");
        } else {
            JOptionPane.showMessageDialog(null, "Error! Couldn't Update book information");
        }

    }

    public void delete(findBook fb) throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/booksDB ", "username", "password");

        String sql = "DELETE FROM BOOKS_TBL WHERE ISBN = ?";

        PreparedStatement prepStatement = connection.prepareStatement(sql);

        prepStatement.setString(1, fb.getISBN());

        int valid = prepStatement.executeUpdate();

        if (valid > 0) {
            JOptionPane.showMessageDialog(null, "Deleted!");
        } else {
            JOptionPane.showMessageDialog(null, "Error! Couldn't Delete book");
        }

    }

}
