/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.mycput.domain;
import java.io.Serializable;
/**
 *
 * @author Thalitha Sithembiso
 */
public class findBook {


    private String ISBN;
    private String BookTitle;
    private String Catergory;
    private String Name;
    private String  ShelfNumber;

    public findBook() {
    }

    public findBook(String ISBN, String BookTitle, String Catergory, String Name, String ShelfNumber) {
        this.ISBN = ISBN;
        this.BookTitle = BookTitle;
        this.Catergory = Catergory;
        this.Name = Name;
        this.ShelfNumber = ShelfNumber;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getBookTitle() {
        return BookTitle;
    }

    public void setBookTitle(String BookTitle) {
        this.BookTitle = BookTitle;
    }

    public String getCatergory() {
        return Catergory;
    }

    public void setCatergory(String Catergory) {
        this.Catergory = Catergory;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getShelfNumber() {
        return ShelfNumber;
    }

    public void setShelfNumber(String ShelfNumber) {
        this.ShelfNumber = ShelfNumber;
    }

    @Override
    public String toString() {
        return "findBook{" + "ISBN=" + ISBN + ", BookTitle=" + BookTitle + ", Catergory=" + Catergory + ", Name=" + Name + ", ShelfNumber=" + ShelfNumber + '}';
    }
    
    

}


