/**
 *
 * @author nxusani
 */
package dao;

import domain.Learner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class LearnerDAO {

    Connection connection = null;

    public LearnerDAO() {
    }

    public void select() throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/LibraryDB", "username", "password");

        String sql = "SELECT * FROM tbl_Learners";

        PreparedStatement pStatement = connection.prepareStatement(sql);

        ResultSet resultSet = pStatement.executeQuery();

    }

    public void insert(Learner learner) throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/LibraryDB", "username", "password");

        String sql = "INSERT INTO tbl_Learners (STUDENTNUMBER, )  VALUES (?,?,?,?,?,?)";

        PreparedStatement pStatement = connection.prepareStatement(sql);
        
        pStatement.setString(1, learner.getStudentNumber());
        pStatement.setString(2, learner.getLastName());
        pStatement.setString(3, learner.getFirstName());
        pStatement.setString(4, learner.getCourse());
        pStatement.setString(5, learner.getBook());

        int ok = pStatement.executeUpdate();

        if (ok > 0) {
            JOptionPane.showMessageDialog(null, "Inserted!");
        } else {
            JOptionPane.showMessageDialog(null, "Error! Couldn't learner into the database");
        }

    }

    public void update(Learner learner) throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/LibraryDB", "username", "password");

        String sql = "UPDATE FROM tbl_Learners SET firstName = ?, lastName =?, StudentNumber =?, Address =? WHERE StudentNumber = ?";

        PreparedStatement pStatement = connection.prepareStatement(sql);

        pStatement.setString(1, learner.getFirstName());
        pStatement.setString(2, learner.getLastName());
        pStatement.setString(3, learner.getStudentNumber());
        pStatement.setString(4, learner.getCourse());

        int ok = pStatement.executeUpdate();

        if (ok > 0) {
            JOptionPane.showMessageDialog(null, "Updated!");
        } else {
            JOptionPane.showMessageDialog(null, "Error! Couldn't Update learner details");
        }

    }

    public void delete(Learner learner) throws SQLException {

        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/LibraryDB", "username", "password");

        String sql = "DELETE FROM tbl_Learners WHERE StudentNumber = ?";

        PreparedStatement pStatement = connection.prepareStatement(sql);

        pStatement.setString(1, learner.getStudentNumber());

        int ok = pStatement.executeUpdate();

        if (ok > 0) {
            JOptionPane.showMessageDialog(null, "Deleted!");
        } else {
            JOptionPane.showMessageDialog(null, "Error! Couldn't Delete learner");
        }

    }

}
