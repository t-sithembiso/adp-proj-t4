package domain;

class Book {

    private int isbn;
    private String BookTitle;
    private String Category;
    private String Author;
    private int ShelfNumber;

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setBookTitle(String bookTitle) {
        this.BookTitle = bookTitle;
    }

    public void setCategory(String category) {
        this.Category = category;
    }

    public void setAuthor(String author) {
        this.Author = author;
    }
    
    public void setShelfNumber (){
        this.ShelfNumber = ShelfNumber;
    }

    public String getBookTitle() {
        return BookTitle;
    }

    public String getCategory() {
        return Category;
    }

    public String getAuthor() {
        return Author;
    }

    public int getShelfNumber() {
        return ShelfNumber;
    }
    

    String title;
    boolean borrowed;
    boolean returned;
    boolean isBorrowed;

    public void borrowed() {
        borrowed = true;
    }

    public void returned() {
        returned = false;
    }

    public boolean isBorrowed() {
        if (returned == false) {
            System.out.println("Book is available for borrowing");
        } else if (borrowed == true) {
            System.out.println("Book is unavailable for borrowing");
        }

        return true;
    }

    public void setToBorrowed() {
        isBorrowed = true;
    }

    public void setToReturned() {
        isBorrowed = false;
    }

}
