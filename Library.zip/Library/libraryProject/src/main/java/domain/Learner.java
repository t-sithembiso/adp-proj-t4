/**
 *
 * @author nxusani
 */
package domain;

import java.util.ArrayList;
import java.util.List;
import domain.Book;

public class Learner {

    private String firstName;
    private String lastName;
    private String studentNumber;
    private String Course;
    private String Book;

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setCourse(String Course) {
        this.Course = Course;
    }

    public void setBook(String Book) {
        this.Book = Book;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getCourse() {
        return Course;
    }

    public String getBook() {
        return Book;
    }

    List<Book> books = new ArrayList<>();

    public boolean borrowBook() {
        for (Book b : books) {
            if (!b.isBorrowed()) {
                b.setToBorrowed();
                return true;
            }
        }
        System.out.println("All books are borrowed, sorry");
        return false;
    }

    public boolean returnBook() {
        for (Book b : books) {
            if (b.isBorrowed()) {
                b.setToReturned();
                return true;
            }
        }
        System.out.println("");
        return false;
    }
}