
import java.awt.print.Book;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;




/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Comp
 */
public class bookDAO_Implementation implements dao{
//Still figuring this part out
    @Override
    public Book get(int ISBN) throws SQLException {
        Connection con= DBclass.getConnection();
        Book books= null;
        
        String sql= "SELECT ISBN, bookTitle, catergory, author, shelfNumber, availableForloan FROM tblname";
        PreparedStatement ps = con. prepareStatement(sql);
        ps.setInt(1, ISBN);
        ResultSet rs= ps.executeQuery();
        
        //getting fields from db
        if (rs.next()){
            int bISBN= rs.getInt
                    int bookID= rs.grt("ISBN");
        }
return books;    }

    @Override
    public List<Book> getAll() throws SQLException {
return null;    }

    @Override
    public int save(Book t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(Book t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(Book t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
