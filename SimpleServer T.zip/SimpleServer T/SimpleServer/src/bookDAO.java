
import java.sql.SQLException;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Comp
 */
public interface bookDAO<T> {
    
    T get (int ISBN) throws SQLException;
    List<T> getAll() throws SQLException;
    
    int save (T t) throws SQLException;
    int insert (T t) throws SQLException;
    int delete (T t);
    
    
}
