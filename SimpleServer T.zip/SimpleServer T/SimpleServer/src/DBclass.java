
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Comp
 */
public class DBclass {
    private static String url="";
    private static String user="";
    private static String password="";

    public DBclass() {
    }
    
    public static Connection getConnection() throws SQLException{
    Connection connection= null;
    connection = DriverManager.getConnection(url,user,password);
    
    return connection;

}
    public static void main (String[] args) throws SQLException{
    Connection con= DBclass.getConnection();
    if (con != null){
        System.err.println("Connected sucessfully");
    
    }
    }
}
