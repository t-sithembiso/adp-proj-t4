/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.views;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Thalitha Sithembiso
 */
public class findBook implements ActionListener{
    
    JButton BtnSave;
      JButton BtnClose;
      JButton BtnReset;
      
     JTextField txtISBN;
    JTextField txtBookTitle;
    JTextField txtCatergory;
    JTextField txtName;
    JTextField txtShelfNumber;
 
      public void GUI(){
          //PANELS AND JFRAME
          JFrame frame = new JFrame("BOOKS");
          frame.setSize(500, 600);
          frame.setResizable(false);
         
          
          
          JPanel panelC = new JPanel();
          panelC.setLayout(null);
          panelC.setBackground(Color.gray);
          
          JPanel panelS = new JPanel();
          panelS.setBackground(Color.gray);
          //Banner panel
              JPanel panelN = new JPanel();
          panelN.setBackground(Color.blue);
          JLabel pnlLabel = new JLabel("BOOK MANAGEMENT SYSTEM");
          pnlLabel.setBounds(0, 10, 140, 140);
          panelN.add(pnlLabel);
          

          frame.add(panelC, BorderLayout.CENTER);
          frame.add(panelN, BorderLayout.NORTH);
          frame.add(panelS, BorderLayout.SOUTH);
          
 
      
          
          
          //LABELS AND TEXTFIELDS
           txtISBN = new JTextField();
           txtISBN.setBounds(100, 80, 165, 125);
           txtBookTitle = new JTextField();
          txtBookTitle.setBounds(100, 120, 165, 125);
          txtCatergory = new JTextField();
          txtCatergory.setBounds(100, 180, 165, 125);
          txtName = new JTextField();
          txtName.setBounds(100, 280, 165, 125);
          txtShelfNumber = new JTextField();
          txtShelfNumber.setBounds(100, 380, 165, 125);
         

          JLabel lblISBN = new JLabel("ISBN");
          lblISBN.setBounds(10, 80, 165, 125);
          JLabel lblBookTitle =  new JLabel("Book Title");
          lblBookTitle.setBounds(10, 120, 165, 125);
          JLabel lblCatergory = new JLabel("Catergory");
          lblCatergory.setBounds(10, 180, 165, 125);
          JLabel lblName =  new JLabel("Name");
          lblName.setBounds(10, 280, 165, 125);
          JLabel lblShelfNumber =  new JLabel("Shelf Number");
          lblShelfNumber.setBounds(10, 380, 165, 125);
      
          
         
          panelC.add(lblISBN);
          panelC.add(lblBookTitle);
          panelC.add(lblCatergory);
          panelC.add(lblName);
          panelC.add(lblShelfNumber);
       

          panelC.add(txtISBN);
          panelC.add(txtBookTitle);
          panelC.add(txtCatergory);
          panelC.add(txtName);
          panelC.add(txtShelfNumber);
        

          BtnSave = new JButton("SAVE");
          BtnSave.setBounds(10, 500, 100, 25);
          panelS.add(BtnSave);
          BtnSave.addActionListener(this);

          BtnClose = new JButton("CLOSE");
          BtnClose.setBounds(80, 500, 100, 25);
          panelS.add(BtnClose);
          BtnClose.addActionListener(this);
          
          BtnReset = new JButton("RESET");
          BtnReset.setBounds(160, 500, 100, 25);
          panelS.add(BtnReset);
          BtnReset.addActionListener(this);
          
          
                     frame.setVisible(true);  
          
          frame.addWindowListener(new WindowAdapter() {
              @Override
              public void windowClosing(WindowEvent e) {
                  System.exit(0);
              }

          });
	 
                             

     }@Override
    public void actionPerformed(ActionEvent e){
    System.out.print("btn works");
    
    if (e.getActionCommand().equals("CLOSE")) {
			System.exit(0);               
		} 
    if (e.getActionCommand().equals("RESET")) {
			txtISBN.setText("");
			txtBookTitle.setText("");
			txtCatergory.setText("");
                        txtName.setText("");
                        txtShelfNumber.setText("");
                  

		}
    }
    public static void main (String[]args) {
   
       System.err.println("no way");
      findBook FB = new  findBook();
       FB.GUI();
       
       
   } }