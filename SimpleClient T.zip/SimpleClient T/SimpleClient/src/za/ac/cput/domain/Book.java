/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.domain;

/**
 *
 * @author Comp
 */
public class Book {

    private int isbn;
    private String bookTitle;
    private String catergory;
    private String author;
    private int shelfNumber;
    private boolean availableForLoan;

    public Book(int isbn, String bookString, String catergory, String author, int ShelfNumber,boolean availableForLoan) {

        this.isbn = isbn;
        this.bookTitle = bookTitle;
        this.catergory = catergory;
        this.author = author;
        this.shelfNumber = shelfNumber;
        this.availableForLoan= availableForLoan;

    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public void setCatergory(String catergory) {
        this.catergory = catergory;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setShelfNumber(int shelfNumber) {
        this.shelfNumber = shelfNumber;
    }

    public int getIsbn() {
        return isbn;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getCatergory() {
        return catergory;
    }

    public String getAuthor() {
        return author;
    }

    public int getShelfNumber() {
        return shelfNumber;
    }
      public boolean isAvailableForLoan() {
        return availableForLoan;
    }

    public void setAvailableForLoan(boolean availableForLoan) {
        this.availableForLoan = availableForLoan;
    }

    @Override
    public String toString() {
        String empStr = "Book{" + "isbn=" + isbn + ", bookTitle=" + bookTitle + ", catergory=" + catergory + ", author=" + author + ", shelfNumber=" + shelfNumber +",available for loan"+ availableForLoan+"}";
        return empStr;
    }

    public static void main(String[] args) {
    Book books= new Book(1,"x","x","x",2,true);

    }

}
