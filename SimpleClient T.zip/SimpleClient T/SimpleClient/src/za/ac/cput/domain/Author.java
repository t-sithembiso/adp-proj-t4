package za.ac.cput.domain;

/**
 *
 * @author Thalitha Sithembiso
 */
public class Author {
    
     private int authorID;
    private String Name;
    private String Country;

    public Author(int authorID, String Name, String Country) {
        this.authorID = authorID;
        this.Name = Name;
        this.Country = Country;
    }

    public int getAuthorID() {
        return authorID;
    }

    public void setAuthorID(int authorID) {
        this.authorID = authorID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    @Override
    public String toString() {
        return "Author{" + "authorID=" + authorID + ", Name=" + Name + ", Country=" + Country + '}';
    }
   
    
    
    
}
